# NovaForge AI — mobile creator studio starter

This is a static, mobile-friendly starter website designed to be edited and hosted from an Android phone.

## Included and working
- Responsive dark-themed workspace with chat, image, song, and video tabs
- Gemini text chat and image-question flow using a key entered by each visitor
- Browser-local chat history (`localStorage`)
- Browser speech input when supported
- Song/video prompt brief builders and external service links
- Image-generation request attempt using `gemini-2.5-flash-image`; availability depends on current model access, API key, region, and quota
- Branding rename control

## Important limits
- This is **not** a trained, independent AI model.
- Music and video tabs create prompts only. They do not generate audio/video. Connect an authorized provider API to enable real rendering.
- The static version uses bring-your-own-key. Each visitor must supply their own Gemini API key. It is kept in `sessionStorage` for that browser tab, not sent to your server, but client-side keys are not appropriate for a production public service. For a public app with a shared owner-funded API, add a backend that stores secrets server-side, rate-limits requests, and protects against abuse.
- Google AI model names, API availability, quotas, free tiers, and terms can change. Check the current official AI Studio documentation. A request may fail if a model isn't available for your account or region.
- Chat history is stored locally on that device/browser only.
- Speech recognition depends on browser support and permissions.
- This project does not include login, cloud-synced memory, a database, or abuse protection.

## Quick test on Android
1. Extract the ZIP using your phone's file manager.
2. Open `index.html` in a browser for a quick UI test. Some browsers restrict API calls or speech features from `file://`; for full testing, host it over HTTPS.
3. Go to Settings & API, get a key from https://aistudio.google.com/apikey, and enter your own key.
4. Test a text question and an image question.
5. Try Image Studio; if the image model is unavailable, the UI reports the error rather than faking an image.
6. Song Studio and Video Studio are prompt tools only until you connect real generation providers.

## Host for free with GitHub Pages (Android only)
1. Create/sign in to GitHub: https://github.com
2. Create a new **public** repository, e.g. `my-ai-studio`.
3. Upload `index.html`, `style.css`, and `app.js` from this ZIP to the repository root. (You can upload them using GitHub's web interface; do not upload API keys.)
4. In the repository, open **Settings → Pages**.
5. Under build/deployment, select **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
6. Wait for the published URL shown on the Pages settings screen. Open it on your phone.
7. The published site is public, but any AI API key entered in this BYOK starter belongs to each visitor. Never put your private API key in the repository.

GitHub Pages hosts only static files; it cannot run a private server-side API. For a production public site, use a free-tier backend/serverless service and server-side secrets, and configure rate limits before sharing widely.

## Security notes
- Don't paste your API key into a public issue or chat.
- This starter does not collect passwords or have an admin dashboard.
- Public deployment means anyone can visit the interface. It does not mean unlimited shared AI usage.
